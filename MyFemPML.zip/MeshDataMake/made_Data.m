clc
clear all

model=mphload('single_PML.mph');

[m1, m2]=mphmeshstats(model);

fposition_PML_test = m2.vertex;

felement_PML_test = cell(1,3);

felement_PML_test{1}=struct('type','vtx','elem',m2.elem{3},'dom',m2.elementity{3});
felement_PML_test{2}=struct('type','edg','elem',1+m2.elem{1},'dom',(m2.elementity{1}).');
felement_PML_test{3}=struct('type','tri','elem',1+m2.elem{2},'dom',(m2.elementity{2}).');

save('fposition_PML_test.mat','fposition_PML_test')
save('felement_PML_test.mat','felement_PML_test')

