function varargout = pml_seting(varargin)
% PML_SETING MATLAB code for pml_seting.fig
%      PML_SETING, by itself, creates a new PML_SETING or raises the existing
%      singleton*.
%
%      H = PML_SETING returns the handle to a new PML_SETING or the handle to
%      the existing singleton*.
%
%      PML_SETING('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PML_SETING.M with the given input arguments.
%
%      PML_SETING('Property','Value',...) creates a new PML_SETING or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before pml_seting_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to pml_seting_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help pml_seting

% Last Modified by GUIDE v2.5 30-Dec-2020 16:08:55

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @pml_seting_OpeningFcn, ...
                   'gui_OutputFcn',  @pml_seting_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT
global pmldomin
varargout{1} = pmldomin;


% --- Executes just before pml_seting is made visible.
function pml_seting_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to pml_seting (see VARARGIN)

% Choose default command line output for pml_seting
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes pml_seting wait for user response (see UIRESUME)
% uiwait(handles.PMLSet);
global pmldomin element
select=(1:max(element{3}.dom))';
set(handles.domin_select,'string',select); 

pmldomin=varargin{1}; 
set(hObject,'WindowStyle','modal')%�ö�
uiwait(handles.PMLSet); 

% --- Outputs from this function are returned to the command line.
function varargout = pml_seting_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

delete(hObject)


% --- Executes on selection change in domin_select.
function domin_select_Callback(hObject, eventdata, handles)
% hObject    handle to domin_select (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns domin_select contents as cell array
%        contents{get(hObject,'Value')} returns selected item from domin_select
global pmldomin hdl
domSelect=get(hObject,'value');
set(handles.popupmenu_select,'value',pmldomin(domSelect(1)));
set(hdl{2},'visible','off');
set(hdl{2}(domSelect),'visible','on');

% --- Executes during object creation, after setting all properties.
function domin_select_CreateFcn(hObject, eventdata, handles)
% hObject    handle to domin_select (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu_select.
function popupmenu_select_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_select (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_select contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_select

% global pmldomin hdl
% domSelect = get(hObject,'value');
% set(handles.popupmenu_select,'value',pmldomin(domSelect(1)));

% --- Executes during object creation, after setting all properties.
function popupmenu_select_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_select (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_apply.
function pushbutton_apply_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_apply (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global pmldomin
dominSelect=get(handles.domin_select,'value');
popSelect = get(handles.popupmenu_select,'value');
pmldomin(dominSelect)=popSelect;

% --- Executes on button press in pushbutton_OK.
function pushbutton_OK_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_OK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global pmldomin
dominSelect=get(handles.domin_select,'value');
popSelect = get(handles.popupmenu_select,'value');
pmldomin(dominSelect)=popSelect;
uiresume(handles.PMLSet); 



function edit_PMLA_Callback(hObject, eventdata, handles)
% hObject    handle to edit_PMLA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_PMLA as text
%        str2double(get(hObject,'String')) returns contents of edit_PMLA as a double


% --- Executes during object creation, after setting all properties.
function edit_PMLA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_PMLA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_PMLB_Callback(hObject, eventdata, handles)
% hObject    handle to edit_PMLB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_PMLB as text
%        str2double(get(hObject,'String')) returns contents of edit_PMLB as a double


% --- Executes during object creation, after setting all properties.
function edit_PMLB_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_PMLB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes when user attempts to close PMLSet.
function PMLSet_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to PMLSet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
sel=questdlg('ȷ�Ϸ������ò��ر� ?','ȷ�Ϸ�������PML��','yes','no','no');%���������Ĭ��Ϊno
switch sel
    case 'yes'
        uiresume(handles.PMLSet);
    case 'no'
        return
end
