function varargout = material_seting(varargin)
% MATERIAL_SETING MATLAB code for material_seting.fig
%      MATERIAL_SETING, by itself, creates a new MATERIAL_SETING or raises the existing
%      singleton*.
%
%      H = MATERIAL_SETING returns the handle to a new MATERIAL_SETING or the handle to
%      the existing singleton*.
%
%      MATERIAL_SETING('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MATERIAL_SETING.M with the given input arguments.
%
%      MATERIAL_SETING('Property','Value',...) creates a new MATERIAL_SETING or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before material_seting_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to material_seting_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help material_seting

% Last Modified by GUIDE v2.5 27-Dec-2016 21:49:51

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @material_seting_OpeningFcn, ...
                   'gui_OutputFcn',  @material_seting_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT
global material
varargout{1} = material;



% --- Executes just before material_seting is made visible.
function material_seting_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to material_seting (see VARARGIN)

% Choose default command line output for material_seting
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
% UIWAIT makes material_seting wait for user response (see UIRESUME)
% uiwait(handles.materialSet);

global material element
select=(1:max(element{3}.dom))';
set(handles.domin_select,'string',select);

material=varargin{1}; 
set(hObject,'WindowStyle','modal')%�ö�
uiwait(hObject); 




% --- Outputs from this function are returned to the command line.
function varargout = material_seting_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


delete(hObject)


% --- Executes during object creation, after setting all properties.
function domin_select_CreateFcn(hObject, eventdata, handles)
% hObject    handle to domin_select (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in domin_select.
function domin_select_Callback(hObject, eventdata, handles)
% hObject    handle to domin_select (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global material hdl
domSelect=get(hObject,'value');
set(handles.table_epsilonr,'data',material(:,:,1,domSelect(1)));
set(handles.table_mur,'data',material(:,:,2,domSelect(1)));
set(handles.table_sigma,'data',material(:,:,3,domSelect(1)));
set(hdl{2},'visible','off');
set(hdl{2}(domSelect),'visible','on');



% --- Executes on button press in apply_epsilonr.
function apply_epsilonr_Callback(hObject, eventdata, handles)
% hObject    handle to apply_epsilonr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global material
domSelect=get(handles.domin_select,'value');
material(:,:,1,domSelect)=get(handles.table_epsilonr,'data');

% --- Executes on button press in apply_mur.
function apply_mur_Callback(hObject, eventdata, handles)
% hObject    handle to apply_mur (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global material
domSelect=get(handles.domin_select,'value');
material(:,:,2,domSelect)=get(handles.table_mur,'data');

% --- Executes on button press in apply_sigma.
function apply_sigma_Callback(hObject, eventdata, handles)
% hObject    handle to apply_sigma (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global material
domSelect=get(handles.domin_select,'value');
material(:,:,3,domSelect)=get(handles.table_sigma,'data');

% --- Executes on button press in OK.
function OK_Callback(hObject, eventdata, handles)
% hObject    handle to OK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global material
domSelect=get(handles.domin_select,'value');
material(:,:,1,domSelect)=get(handles.table_epsilonr,'data');
material(:,:,2,domSelect)=get(handles.table_mur,'data');
material(:,:,3,domSelect)=get(handles.table_sigma,'data');
uiresume(handles.materialSet); 



% --- Executes when user attempts to close materialSet.
function materialSet_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to materialSet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
sel=questdlg('ȷ�Ϸ������Ĳ��ر� ?','ȷ�Ϸ������Ĳ��ϲ�����','yes','no','no');%���������Ĭ��Ϊno
switch sel
    case 'yes'
        uiresume(handles.materialSet);
    case 'no'
        return
end
