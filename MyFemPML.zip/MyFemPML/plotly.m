function plotly(parameter)
%��ͼѡ����  1*3����  1��ʾ�Ƿ��ͼ  2ѡ�����Ex/Ey/Ez   3ѡ��ڼ���ģʽ
global hdl hdAxes no2xy el2no n1EL n2EL n3EL EVINf beta ez
axes(hdAxes)
set(get(hdAxes,'children'),'visible','off');
try
    delete(hdl{4});
end
switch parameter(1)
    case 1
        switch parameter(2)
            case 1
                plotEx(no2xy,el2no,n1EL,n2EL,n3EL,real(EVINf),beta,parameter(3));

            case 2
                plotEy(no2xy,el2no,n1EL,n2EL,n3EL,real(EVINf),beta,parameter(3));

            case 3
                plotEz(no2xy,el2no,real(ez),parameter(3));

            otherwise
        end
    otherwise
end