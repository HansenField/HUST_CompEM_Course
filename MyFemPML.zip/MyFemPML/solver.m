function [ neff,beta,ez,EVINf,n1EL,n2EL,n3EL] =solver(no2xy,el2no,domain,lambda0,number_lambda,targetneff,Material,EdgeNode,PMLdomain,A,B)
%���룺no2xy�������ꣻel2noÿ�����ζ��㣻domain��������lambda0���㲨����
%number_lambdaҪ����ģʽ������ncore��о�����ʣ�nclad����������
%�������Ч������neff����������beta���ݳ���Ez���� ez���᳡ EVINf
% plot Ez �ú���plotEz
% plot Ex �ú���plotEx
% plot Ey �ú���plotEy
%%%start
xn=no2xy(1,:); %�ڵ�x����
yn=no2xy(2,:); %�ڵ�y����
n1L=el2no(1,:); %С���������1������
n2L=el2no(2,:); %С���������2������
n3L=el2no(3,:); %С���������3������
Nn = length(xn); % number of nodes  �ڵ���Ŀ
Ne = length(n1L); % number of elements  ����������Ŀ

%edge
[Neg,n1EL,n2EL,n3EL,PECnode1,PECnode2] = edgesxzf(el2no,EdgeNode); 
k0 = 2*pi/lambda0;

%������װ
[~,~,Btz,Bzz,C] = INHWGD(lambda0,Material,domain,PMLdomain,A,B,PECnode1,PECnode2,...
    k0,Neg,Nn,Ne,n1L,n2L,n3L,n1EL,n2EL,n3EL,xn,yn); % calling the INHWGfunction

%���
sigma=-(targetneff*k0)^2;
[EVINf, GAMASQf] = eigs(C,number_lambda,sigma);%����targetneff������ֵ

GAMA = sqrt(((GAMASQf)));
diag_GAMA = diag(GAMA);
beta=-1i*(diag_GAMA);
neff=beta./k0;

ez=-inv(Bzz)*Btz'*EVINf;

%PEC�߽������� �ڵ���ֵ�ָ�
if ~isempty(EdgeNode)
    i=size(PECnode1);i=i(1);
    PECnode1=PECnode1-1;
    PECnode2=PECnode2-1;
    for j=i:-1:1
        m=PECnode1(j);
        n=PECnode2(j);
        EVINf=[EVINf(1:m,:); zeros(1,number_lambda) ; EVINf(m+1:end,:)];
        ez=[ez(1:n,:) ; zeros(1,number_lambda) ; ez(n+1:end,:)];
    end  
end

end
%%
function [Neg, n1EL, n2EL, n3EL,PECnode1,PECnode2] = edgesxzf(el2no,EdgeNode)
%�ɶ�����ű�ʾԪ���ɱ���ţ�����������ʾԪ�ĺ���
n1=el2no([1 2 3],:);
n2=el2no([2 3 1],:);
el_ed2no_array=[n1(:) n2(:)];%ÿ��Ԫ�������Զ����ʾ�������ţ�3*Nele
N=length(el2no);%Nele
sign=ones(3*N,1);%ÿ����ŵķ��ţ����Ŵ�������
for k=1:3*N
    if el_ed2no_array(k,1)>el_ed2no_array(k,2)
        a=el_ed2no_array(k,1);
        el_ed2no_array(k,1)=el_ed2no_array(k,2);
        el_ed2no_array(k,2)=a;
        sign(k)=-1;
    end
end
[ed2no,~,el2ed]=unique(el_ed2no_array,'rows');
%PEC����
if ~isempty(EdgeNode)
    
   PECnode2=EdgeNode(:,1);
   PECnode2=sort(PECnode2,'descend');
   
   i=size(EdgeNode);i=i(1);
   for j=1:i
      if(EdgeNode(j,1)>EdgeNode(j,2))
          a=EdgeNode(j,1);
          EdgeNode(j,1)=EdgeNode(j,2);
          EdgeNode(j,2)=a;
      end
   end
    
   [~ ,Lia2] = ismember(EdgeNode,ed2no,'rows');
   
   PECnode1=sort(Lia2,'descend');
   
else
   PECnode1=[];
   PECnode2=[];
end

el2ed=reshape(el2ed,3,size(el2no,2));
sign=reshape(sign,3,size(el2no,2));
el2ed=sign.*el2ed;
Neg=length(ed2no);
n1EL=el2ed(1,:);
n2EL=el2ed(2,:);
n3EL=el2ed(3,:);
end

%%
    function [Att,Btt,Btz,Bzz,C] = INHWGD(lambda0,Material,domain,PMLdomain,A,B,PECnode1,PECnode2,...
        k0,Neg,Nn,Ne,n1L,n2L,n3L,n1EL,n2EL,n3EL,xn,yn)
        % Inhomogeneous waveguide problem, page 73�C75 texte
        % written by D. K. Kalluri
        % Edge elements for transverse fields and node-based
        % elements for longitudinal fields
        % Global Assembly of two-dimensional edge-based
        % triangular elements
        % Neg = number of edge elements
        % Nn = number of nodes
        % Ne = number of elements
        % n1L = array containing global node number
        % of the first local node of e th element
        % n2L = array containing global node number
        % of the second local node of e th element
        % % n3L = array containing global node number
        % of the third local node of e th element
        % n1EL = array containing global edge number
        % of the first local edge of e th element
        % n2EL = array containing global edge number
        % of the first local edge of e th element
        % n3EL = array containing global edge number
        % of the first local edge of e th element
        % a negative value indicates opposite directions
        % of the global edge and the local edge
        for e = 1:Ne
            n(1,e)= n1L(e);
            n(2,e)= n2L(e);
            n(3,e)= n3L(e);
            ne(1,e)= n1EL(e);
            ne(2,e)= n2EL(e);
            ne(3,e)= n3EL(e);
        end
        % Initialization
        Att = zeros(Neg,Neg);
        Btt = zeros(Neg,Neg);
        Btz = zeros(Neg,Nn);
        Bzz = zeros(Nn,Nn);
        % Loop through all elements
        for e = 1: Ne
            % coordinates of the element nodes
            for i = 1:3
                x(i)= xn(n(i,e));
                y(i)= yn(n(i,e));
            end
            % compute the element matrix entries
            b(1)= y(2)- y(3);
            b(2)= y(3)- y(1);
            b(3)= y(1)- y(2);
            c(1)= x(3)- x(2);
            c(2)= x(1)- x(3);
            c(3)= x(2)- x(1);
            Area = 0.5 * abs (b(2)* c(3)- b(3)* c(2));
            l(1)= sqrt(b(3)* b(3)+ c(3)* c(3));
            l(2)= sqrt(b(1)* b(1)+ c(1)* c(1));
            l(3)= sqrt(b(2)* b(2)+ c(2)* c(2));
            K(1)= l(1)/(12*Area);
            K(2)= l(2)/(12*Area);
            K(3)= l(3)/(12*Area);
            % Compute the element matrix entries
            for i = 1:3
                for j = 1:3
                    if i == j
                        Te(i,j) =Area/6;
                    else
                        Te(i,j) =Area/12;
                    end
                end
            end
                   
            De=domain(1,e);
            
            %PML
            C=B*(1-1i)*lambda0/2-1;D=1+C;E=A*C;
            ss=ones(3,3); %i�͵��й�   j1/2 
            if (PMLdomain(De)==2)
                for i=1:3
                    for j=1:3
                        rr=sqrt(x(j)*x(j)+y(j)*y(j));
                        detInvT=D*D-E*D/rr;
                        switch i
                            case 1
                                dy=D-E/rr+E*y(j)*y(j)/(rr*rr*rr);
                                ss(i,j)=dy*dy/detInvT;
                                
                            case 2
                                dx=D-E/rr+E*x(j)*x(j)/(rr*rr*rr);
                                ss(i,j)=dx*dx/detInvT;
                            case 3
                                ss(i,j)=detInvT;
                            otherwise
                        end
                    end
                end
            end
            
            %����������Լӽ�����Ctt3��
            epsr11 = Material(1,1,1,De);epsr12 = 0;epsr13 =0;
            epsr21 = 0;epsr22 = Material(2,2,1,De);epsr23 = 0;
            epsr31 = 0;epsr32 = 0;epsr33 = Material(3,3,1,De);

            mur11=Material(1,1,2,De);mur12=0;mur13=0;
            mur21=0;mur22=Material(2,2,2,De);mur23=0;
            mur31=0;mur32=0;mur33=Material(3,3,2,De);
            
            C_tt3=zeros(3,3);
            
            C_tt31 = assemble_C_tt3(x(1),x(2),x(3),y(1),y(2),y(3),epsr11*ss(1,1),0,0,epsr22*ss(2,1));
            C_tt32 = assemble_C_tt3(x(1),x(2),x(3),y(1),y(2),y(3),epsr11*ss(1,2),0,0,epsr22*ss(2,2));
            C_tt33 = assemble_C_tt3(x(1),x(2),x(3),y(1),y(2),y(3),epsr11*ss(1,3),0,0,epsr22*ss(2,3));
            C_tt3(:,1)=C_tt31(:,1);
            C_tt3(:,2)=C_tt32(:,2);
            C_tt3(:,3)=C_tt33(:,3);
            
            mur=zeros(3);
            mur(1)=mur11;
            mur(2)=mur22;
            mur(3)=mur33;
            
            Mur_tt3=zeros(3,3);
            Mur_tt31 = assemble_C_tt3(x(1),x(2),x(3),y(1),y(2),y(3),1/(mur(2)*ss(2,1)),0,0,1/(mur(1)*ss(1,1)));
            Mur_tt32 = assemble_C_tt3(x(1),x(2),x(3),y(1),y(2),y(3),1/(mur(2)*ss(2,2)),0,0,1/(mur(1)*ss(1,2)));
            Mur_tt33 = assemble_C_tt3(x(1),x(2),x(3),y(1),y(2),y(3),1/(mur(2)*ss(2,3)),0,0,1/(mur(1)*ss(1,3)));
            Mur_tt3(:,1)=Mur_tt31(:,1);
            Mur_tt3(:,2)=Mur_tt32(:,2);
            Mur_tt3(:,3)=Mur_tt33(:,3);
            
            Se=zeros(3,3);
            for i = 1:3
                for j = 1:3
                    Se(i,j)= (0.25/Area)*(b(i)*b(j)/(mur(2)*ss(2,j))+ c(i) *c(j)/(mur(1)*ss(1,j)));
                end
            end
            
            %G��   Btz��   �����Ҫ��ת��
            Gtz1(1,1)=K(1)*( (b(2)*b(1)-b(1)*b(1))/(mur(2)*ss(2,1)) + (c(2)*c(1)-c(1)*c(1))/(mur(1)*ss(1,1)) );
            Gtz1(1,2)=K(1)*( (b(2)*b(2)-b(1)*b(2))/(mur(2)*ss(2,2)) + (c(2)*c(2)-c(1)*c(2))/(mur(1)*ss(1,2)) );
            Gtz1(1,3)=K(1)*( (b(2)*b(3)-b(1)*b(3))/(mur(2)*ss(2,3)) + (c(2)*c(3)-c(1)*c(3))/(mur(1)*ss(1,3)) );
            Gtz1(2,1)=K(2)*( (b(3)*b(1)-b(2)*b(1))/(mur(2)*ss(2,1)) + (c(3)*c(1)-c(2)*c(1))/(mur(1)*ss(1,1)) );
            Gtz1(2,2)=K(2)*( (b(3)*b(2)-b(2)*b(2))/(mur(2)*ss(2,2)) + (c(3)*c(2)-c(2)*c(2))/(mur(1)*ss(1,2)) );
            Gtz1(2,3)=K(2)*( (b(3)*b(3)-b(2)*b(3))/(mur(2)*ss(2,3)) + (c(3)*c(3)-c(2)*c(3))/(mur(1)*ss(1,3)) );
            Gtz1(3,1)=K(3)*( (b(1)*b(1)-b(3)*b(1))/(mur(2)*ss(2,1)) + (c(1)*c(1)-c(3)*c(1))/(mur(1)*ss(1,1)) );
            Gtz1(3,2)=K(3)*( (b(1)*b(2)-b(3)*b(2))/(mur(2)*ss(2,2)) + (c(1)*c(2)-c(3)*c(2))/(mur(1)*ss(1,2)) );
            Gtz1(3,3)=K(3)*( (b(1)*b(3)-b(3)*b(3))/(mur(2)*ss(2,3)) + (c(1)*c(3)-c(3)*c(3))/(mur(1)*ss(1,3)) );
            
            Ee=zeros(3,3);
            Atte=zeros(3,3);
            Btte=zeros(3,3);
            Btze=zeros(3,3);
            Bzze=zeros(3,3);
            
            for i = 1:3
                for j = 1:3
                    Ee(i,j)= (1/Area)*(l(i)*l(j))*(1/(mur(3)*ss(3,j)));
                    % Assemble the Element matrices into Global FEM System
                    if (ne(i,e)< 0)
                        Ee(i,j)= -Ee(i,j);
                        Gtz1(i,j)= -Gtz1(i,j);
                        C_tt3(i,j)=-C_tt3(i,j);
                        Mur_tt3(i,j)=-Mur_tt3(i,j);
                    else
                    end
                    if (ne(j,e)< 0)
                        Ee(i,j)= -Ee(i,j);
                        C_tt3(i,j)=-C_tt3(i,j);
                        Mur_tt3(i,j)=-Mur_tt3(i,j);
                    else
                    end
                    
                    %PML  ��������weak form
                    Atte(i,j)= Ee(i,j)- k0*k0*C_tt3(i,j);
                    Btte(i,j)= Mur_tt3(i,j);
                    Btze(i,j)= Gtz1(i,j);
                    Bzze(i,j)= Se(i,j)- k0*k0*Te(i,j)*epsr33*ss(3,j);
                    % for storing purposes take absolute value of
                    % ne(i,e) and ne(j,e) which may have negative values
                    ane(i,e)= abs(ne(i,e));
                    ane(j,e)= abs(ne(j,e));
                    Att(ane(i,e),ane(j,e))= Att(ane(i,e),ane(j,e))+ Atte(i,j);
                    Btt(ane(i,e),ane(j,e))= Btt(ane(i,e),ane(j,e))+ Btte(i,j);
                    Btz(ane(i,e),n(j,e))= Btz(ane(i,e),n(j,e))+ Btze(i,j);
                    Bzz(n(i,e),n(j,e))= Bzz(n(i,e),n(j,e))+ Bzze(i,j);
                end
            end
        end
        
        %PEC
        if ~isempty(PECnode1)
           i=size(PECnode1);i=i(1);
           for j=1:i
               PECe=PECnode1(j);
               PECn=PECnode2(j);
               Att(:,PECe)=[];
               Att(PECe,:)=[];
               Btt(:,PECe)=[];
               Btt(PECe,:)=[];
               Bzz(PECn,:)=[];
               Bzz(:,PECn)=[];
               Btz(:,PECn)=[];
               Btz(PECe,:)=[];
           end
        end
        
        C1 = Btt - Btz*(Bzz\(Btz'));
        C = C1\Att;
        
    end