function varargout = My_Fem_PML(varargin)
% MY_FEM_PML MATLAB code for My_Fem_PML.fig
%      MY_FEM_PML, by itself, creates a new MY_FEM_PML or raises the existing
%      singleton*.
%
%      H = MY_FEM_PML returns the handle to a new MY_FEM_PML or the handle to
%      the existing singleton*.
%
%      MY_FEM_PML('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MY_FEM_PML.M with the given input arguments.
%
%      MY_FEM_PML('Property','Value',...) creates a new MY_FEM_PML or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before My_Fem_PML_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to My_Fem_PML_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help My_Fem_PML

% Last Modified by GUIDE v2.5 30-Dec-2020 15:26:29

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @My_Fem_PML_OpeningFcn, ...
                   'gui_OutputFcn',  @My_Fem_PML_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before My_Fem_PML is made visible.
function My_Fem_PML_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to My_Fem_PML (see VARARGIN)

% Choose default command line output for My_Fem_PML
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

%ȫ�ֱ�������
clear global
global position element hdAxes hdl %position��elementΪcomsol������mesh����
position=[];%������ʾ��δ����ֵ
element=[]; %������ʾ��δ����ֵ
hdAxes = handles.axes1; %Ϊ��������
hdl{4}=[]; %hdl���ڴ洢����plot��handle��hdl{1}Ϊmesh�ģ�{2}Ϊmaterial�ģ�{3}Ϊboundary�ģ�{4}Ϊresult��

% UIWAIT makes My_Fem_PML wait for user response (see UIRESUME)
% uiwait(handles.figure1);

%���ڹر�
% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
sel=questdlg('ȷ�Ϲرգ�','�ر�','yes','no','no');%���������Ĭ��Ϊno
switch sel
    case 'yes'
        delete(hObject)
    case 'no'
        return
end


% --- Outputs from this function are returned to the command line.
function varargout = My_Fem_PML_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%���κ������ȡ
% --- Executes on button press in pushbutton_mesh.
function pushbutton_mesh_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_mesh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global position element hdl 
if isempty(hdl{1})
    [filename,filepath] = uigetfile('*.mat','Select mesh point position file'); 
    if filename==0  %ȡ�����ļ�ѡ��ʱ
    else
        load([filepath,filename]);
        [~, name, ~] = fileparts(filename);   %fileparts�����·�������ơ���׺  ��ȡ����ڵ��ļ�
        position=eval(name);
        [filename,filepath] = uigetfile([filepath,'*.mat'],'Select mesh element file'); %���øղ�ѡ����ļ�·��ΪĬ��
        if filename==0
        else
            load([filepath,filename]);
            [~, name, ~] = fileparts(filename);   %fileparts�����·�������ơ���׺   ��ȡ�����ļ�
            element=eval(name);            
            meshplot;%��������
            
            %���ϲ�����ʼ��
            maxel=max(element{3}.dom);
            Material(3,3,3,maxel)=0;
            set(handles.pushbutton_material,'userdata',Material);
            
            %���ϲ�������ѡ���ͼ
            for k=1:maxel
                domin=find(element{3}.dom==k); %�����������Ľṹ���򣬲��������α��
                xy1=position(:,element{3}.elem(1,domin));  %���������εĵ�1�����xy��������.��ȡ��������Ϣ
                xy2=position(:,element{3}.elem(2,domin));  %���������εĵ�2�����xy��������
                xy3=position(:,element{3}.elem(3,domin));  %���������εĵ�3�����xy��������
                X=[xy1(1,:);xy2(1,:);xy3(1,:)];  %��ȡ�����ε�����
                Y=[xy1(2,:);xy2(2,:);xy3(2,:)];
                hdl{2}(k)=patch(X,Y,'g','visible','off');
            end
            
            %PML��ʼ��
            pmldomin=ones(1,maxel);
            set(handles.pushbutton_PML,'userdata',pmldomin);
            
            %�߽�ѡ���ͼ
            maxbd=max(element{2}.dom);
            Boundary(1:maxbd)=1;  %=1Ĭ�϶�ΪPEC���������ʼ��ʱΪ��ÿ�����½���button_boundary��ʱ���ܱ���֮ǰ���õı߽����Բ��ᱻ����ΪPEC
            set(handles.pushbutton_boudary,'userdata',Boundary);
            %������boundaryͼ
            for k=1:maxbd
                boundLine = find(element{2}.dom==k);%��ȡ�����ڲ�ͬboundary���߶εı��
                xy1=position(:,element{2}.elem(1,boundLine));  
                xy2=position(:,element{2}.elem(2,boundLine));  
                xy=[xy1;xy2;xy1*NaN];  
                hdl{3}(k) = plot(xy(1:2:end),xy(2:2:end),'r','LineWidth',2,'visible','off');
            end
        end
    end
else
    set(get(gca,'children'),'visible','off')
    set(hdl{1},'visible','on');
end

%���ϲ�������
% --- Executes on button press in pushbutton_material.
function pushbutton_material_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_material (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global hdl    
if isempty(hdl{1}) % δ��meshͼ������δ����mesh
    warndlg(' ���ȵ��� mesh ���� !','��ʾ��','modal')
else
    set(get(gca,'children'),'visible','off');
    set(hdl{1},'visible','on');
    Material=material_seting(get(hObject,'userdata'));
    set(hObject,'userdata',Material);
    set(hdl{2},'visible','off'); %�ظ�ΪĬ�ϻ�ͼ
end

%PEC PMC�߽���������
% --- Executes on button press in pushbutton_boudary.
function pushbutton_boudary_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_boudary (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global hdl  
if isempty(hdl{1}) % δ��meshͼ������δ����mesh
    warndlg(' ���ȵ��� mesh ���� !','��ʾ��','modal')
else
    set(get(gca,'children'),'visible','off');
    set(hdl{1}(2),'visible','on');
    Boundary=boundary_seting(get(hObject,'userdata'));% 1*n���� nΪ���� ��ֵ1���������ⲿ�߽� ��ֵ2����PEC ��ֵ3����PMC
    set(hObject,'userdata',Boundary);
end

%PML��������  PML�����������
% --- Executes on button press in pushbutton_PML.
function pushbutton_PML_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_PML (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global hdl    
if isempty(hdl{1}) % δ��meshͼ������δ����mesh
    warndlg(' ���ȵ��� mesh ���� !','��ʾ��','modal')
else
    set(get(gca,'children'),'visible','off');
    set(hdl{1},'visible','on');
    PMLdomain=pml_seting(get(hObject,'userdata'));
    set(hObject,'userdata',PMLdomain); %1*n����  n=max(domin)  1Ϊnormal 2ΪPML
    set(hdl{2},'visible','off'); %�ظ�ΪĬ�ϻ�ͼ
end

%���
% --- Executes on button press in pushbutton_solve.
function pushbutton_solve_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_solve (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global position element neff beta k0 ez EVINf n1EL n2EL n3EL no2xy el2no

wavelength=str2num(get(handles.edit_wavelength,'string'));%����
modenum=str2num(get(handles.edit_modenum,'string'));%ģʽ��Ŀ
targetneff=str2num(get(handles.edit_neff,'string'));%Ŀ����Ч������

k0=2*pi/wavelength;
no2xy=position;
el2no=element{3}.elem;
domain=element{3}.dom;
lambda0=wavelength;
number_lambda=modenum;
%���ϲ���
n=get(handles.pushbutton_material,'userdata');

%�߽����� 1*n����  EdgeNode
Boundary=get(handles.pushbutton_boudary,'userdata');
j=1; %ȷ��PEC�߽���
PECbd=[];
for i=1:length(Boundary)
   if  Boundary(i)==2
       PECbd(j)=i;
       j=j+1;
   end
end

if ~isempty(PECbd)
    j=1;
    for i=1:length(element{2}.elem)
        a=element{2}.dom(1,i);
        if ismember(a,PECbd)%�ж��Ƿ�ΪPEC�߽�
            EdgeNode(:,j)=element{2}.elem(:,i);
            j=j+1;
        end
    end
    EdgeNode=EdgeNode';%����PEC�����ı߽�����
else
    EdgeNode=[];
end

%PML����
PMLdomain=get(handles.pushbutton_PML,'userdata');
PMLA=str2num(get(handles.edit_PMLA,'string'));%PML��뾶
PMLB=str2num(get(handles.edit_PMLB,'string'));%PML�ڰ뾶
A=PMLA-PMLB;B=2/PMLB;%PML�������

h=msgbox('���ڼ���...','���ڼ���...','modal');

[neff,beta,ez,EVINf,n1EL,n2EL,n3EL] =solver(no2xy,el2no,domain,lambda0,number_lambda,targetneff,n,EdgeNode,PMLdomain,A,B);

try
    delete(h);
end
%��������
for i=1:modenum
    list_string{i}=num2str(neff(i));
end
set(handles.popupmenu_ModeList,'String',list_string);


% --- Executes on button press in pushbutton_result.
function pushbutton_result_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_result (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit_wavelength_Callback(hObject, eventdata, handles)
% hObject    handle to edit_wavelength (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_wavelength as text
%        str2double(get(hObject,'String')) returns contents of edit_wavelength as a double


% --- Executes during object creation, after setting all properties.
function edit_wavelength_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_wavelength (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_modenum_Callback(hObject, eventdata, handles)
% hObject    handle to edit_modenum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_modenum as text
%        str2double(get(hObject,'String')) returns contents of edit_modenum as a double


% --- Executes during object creation, after setting all properties.
function edit_modenum_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_modenum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%����Ex
% --- Executes on button press in pushbuttonEx.
function pushbuttonEx_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonEx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
neffnum=get(handles.popupmenu_ModeList,'Value');
plotly([1,1,neffnum]);

%����Ey
% --- Executes on button press in pushbuttonEy.
function pushbuttonEy_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonEy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
neffnum=get(handles.popupmenu_ModeList,'Value');
plotly([1,2,neffnum]);

%����Ez
% --- Executes on button press in pushbuttonEz.
function pushbuttonEz_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonEz (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
neffnum=get(handles.popupmenu_ModeList,'Value');
plotly([1,3,neffnum]);



function edit_neff_Callback(hObject, eventdata, handles)
% hObject    handle to edit_neff (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_neff as text
%        str2double(get(hObject,'String')) returns contents of edit_neff as a double


% --- Executes during object creation, after setting all properties.
function edit_neff_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_neff (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on selection change in popupmenu_ModeList.
function popupmenu_ModeList_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_ModeList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_ModeList contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_ModeList

% --- Executes during object creation, after setting all properties.
function popupmenu_ModeList_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_ModeList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_PMLA_Callback(hObject, eventdata, handles)
% hObject    handle to edit_PMLA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_PMLA as text
%        str2double(get(hObject,'String')) returns contents of edit_PMLA as a double


% --- Executes during object creation, after setting all properties.
function edit_PMLA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_PMLA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_PMLB_Callback(hObject, eventdata, handles)
% hObject    handle to edit_PMLB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_PMLB as text
%        str2double(get(hObject,'String')) returns contents of edit_PMLB as a double


% --- Executes during object creation, after setting all properties.
function edit_PMLB_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_PMLB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
