function varargout = boundary_seting(varargin)
% BOUNDARY_SETING MATLAB code for boundary_seting.fig

% Edit the above text to modify the response to help boundary_seting

% Last Modified by GUIDE v2.5 30-Dec-2020 15:16:09

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @boundary_seting_OpeningFcn, ...
                   'gui_OutputFcn',  @boundary_seting_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT
global boundary  
varargout{1} = boundary;


% --- Executes just before boundary_seting is made visible.
function boundary_seting_OpeningFcn(hObject, eventdata, handles, varargin)

% Choose default command line output for boundary_seting
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);


global element boundary
select=(1:max(element{2}.dom))';
set(handles.boundary_select,'string',select);
boundary=varargin{1};
set(handles.boundarySet,'WindowStyle','modal')%�ö�
uiwait(handles.boundarySet); 



% --- Outputs from this function are returned to the command line.
function varargout = boundary_seting_OutputFcn(hObject, eventdata, handles) 

% Get default command line output from handles structure
varargout{1} = handles.output;

delete(handles.boundarySet)

% --- Executes on selection change in boundary_select.
function boundary_select_Callback(hObject, eventdata, handles)
global boundary hdl
boundSelect = get(hObject,'value');
set(handles.popmenu_boundary,'value',boundary(boundSelect(1)));
set(hdl{3},'visible','off');
set(hdl{3}(boundSelect),'visible','on');



% --- Executes during object creation, after setting all properties.
function boundary_select_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function popmenu_boundary_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in Apply.
function Apply_Callback(hObject, eventdata, handles)
global boundary
boundSelect = get(handles.boundary_select,'value');
popSelect = get(handles.popmenu_boundary,'value');
boundary(boundSelect)=popSelect;


% --- Executes on button press in OK.
function OK_Callback(hObject, eventdata, handles)
global boundary
boundSelect = get(handles.boundary_select,'value');
popSelect = get(handles.popmenu_boundary,'value');
boundary(boundSelect)=popSelect;
uiresume(handles.boundarySet); 


% --- Executes on button press in cancel.
function cancel_Callback(hObject, eventdata, handles)

uiresume(handles.boundarySet);



% --- Executes when user attempts to close boundarySet.
function boundarySet_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to boundarySet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
sel=questdlg('ȷ�Ϸ������ò��ر� ?','ȷ�Ϸ������ñ߽�������','yes','no','no');%���������Ĭ��Ϊno
switch sel
    case 'yes'
        uiresume(handles.boundarySet);
    case 'no'
        return
end
